
for (let index = 0; index < 11; index++) {
    document.write(index);
}// Esse código faz a seguinte função: Ele é uma repetição, ele cria uma variavel que é um contador, se a variavel for menor que 11 ele fica repetindo, e a cada vez que ele refaz o processo eu peço pra ele adicionar +1 no contador, até que ele pare chegando em 11.