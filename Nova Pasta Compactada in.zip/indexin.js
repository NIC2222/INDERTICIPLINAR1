document.addEventListener('DOMContentLoaded', (event) => {
    const botao = document.getElementById('burger');
    var div = document.getElementById('barra-topo');
    var flag = true;
    var div2 = document.getElementById("links");
    botao.addEventListener('click', () => {
         if (flag) {
            div.style.height = '170px';
            div.style.transition = 'height 1s'; /* Ajuste a transição para altura */
            div2.style.display = 'flex'; /* Alterado para flex */
            flag = false;
        } else {
            div.style.height = '111px';
            div.style.transition = 'height 1s'; /* Ajuste a transição para altura */
            flag = true;
            div2.style.display = 'none';
        }
         });
});